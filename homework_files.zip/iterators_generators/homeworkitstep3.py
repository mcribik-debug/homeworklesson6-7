def powers_of_three(max_exponent):
    """Генератор ступенів числа 3: 3^0, 3^1, 3^2, ..."""
    for exponent in range(max_exponent + 1):
        yield 3 ** exponent


for power in powers_of_three(8):
    print(power, end=" ")
print()
