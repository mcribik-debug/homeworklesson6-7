def make_sum_counter():
    """Замикання, яке накопичує суму переданих значень."""
    total = 0

    def add(value):
        nonlocal total
        total += value
        return total

    return add


counter = make_sum_counter()
print(counter(5))
print(counter(10))
print(counter(3))
