def make_adder(extra):
    """Замикання, яке зберігає параметр extra і додає його до вхідного значення."""

    def add(value):
        return value + extra

    return add


add_five = make_adder(5)
add_ten = make_adder(10)

print(add_five(3))
print(add_ten(3))
