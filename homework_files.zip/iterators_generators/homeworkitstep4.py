import random
import string


def random_letters(count):
    """Генератор випадкових букв англійського алфавіту."""
    for _ in range(count):
        yield random.choice(string.ascii_letters)


print(" ".join(random_letters(10)))
