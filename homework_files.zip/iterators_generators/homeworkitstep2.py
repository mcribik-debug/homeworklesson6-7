class PowersOfTwo:
    """Ітератор ступенів числа 2: 2^0, 2^1, 2^2, ..."""

    def __init__(self, max_exponent):
        self.max_exponent = max_exponent
        self.exponent = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self.exponent > self.max_exponent:
            raise StopIteration
        value = 2 ** self.exponent
        self.exponent += 1
        return value


for power in PowersOfTwo(10):
    print(power, end=" ")
print()
