class WordLengthIterator:
    """Ітератор, що обходить список слів і повертає довжину кожного."""

    def __init__(self, words):
        self.words = words
        self.index = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self.index >= len(self.words):
            raise StopIteration
        word = self.words[self.index]
        self.index += 1
        return word, len(word)


words = ["яблуко", "груша", "апельсин", "ківі"]
for word, length in WordLengthIterator(words):
    print(f"{word}: {length}")
