import logging

logging.basicConfig(
    filename="task2.log",
    level=logging.ERROR,
    format="%(asctime)s - %(levelname)s - %(message)s",
    encoding="utf-8",
)

try:
    result = 10 / 0
except ZeroDivisionError as e:
    logging.error(f"Сталася помилка: {e}")
    print("Помилку записано в task2.log")
