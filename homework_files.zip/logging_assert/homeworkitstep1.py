import logging
from datetime import date

logging.basicConfig(
    filename="task1.log",
    level=logging.INFO,
    format="%(levelname)s - %(message)s",
    encoding="utf-8",
)

today = date.today().strftime("%Y-%m-%d")
logging.info(f"Поточна дата: {today}")
print("Повідомлення записано в task1.log")
