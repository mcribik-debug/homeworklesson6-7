CORRECT_USERNAME = "admin"
CORRECT_PASSWORD = "12345"


def login(username, password):
    try:
        assert (
            username == CORRECT_USERNAME and password == CORRECT_PASSWORD
        ), "Невірне ім'я користувача або пароль"
        print("Вхід виконано успішно")
    except AssertionError as e:
        print(e)


login("admin", "12345")
login("admin", "wrong")
